# Research report: Sales pipeline and revenue forecasting

## Executive summary

**A better forecast still needs a warning system.**

In the stable simulation, the detailed model's 12-week revenue error was 6.5%, versus 19.6% for fixed stage weights. The simpler timing model was slightly more accurate at 6.0%.

Decision implication: Pilot the forecast alongside the existing sales process, with clear alerts when conversion rates or deal timing change.

Key caution: When the simulated sales process slowed abruptly, all twelve 95% forecast ranges missed. The forecast covers only opportunities already open. It cannot support a firm revenue commitment.

All findings describe synthetic data. They are not client results. Independent technical review remains pending.

## Decision and design

Create a 4-, 8- and 12-week revenue outlook for opportunities already open at the forecast date. Separate conversion and timing uncertainty from sales commitments. Future opportunities are outside the forecast population.

Three implemented forecasters are evaluated at twelve held-out forecast dates, over three horizons and three declared scenarios. The study generates 5,760 opportunities per scenario and preserves weekly point-in-time snapshots. No final-period tuning is used.

## Method

Estimate weekly probabilities of staying in stage, advancing, winning or losing. The primary model conditions on three stages, two segments and three age bands, with Dirichlet smoothing. Propagate these competing transitions to horizon-specific win probabilities. Aggregate 500 posterior predictive draws that share a sampled transition table across opportunities, then simulate individual paths. Compare against the same open pipeline under both baselines.

- Twelve forecast origins, four weeks apart; 4-, 8- and 12-week outcomes are fully observed.
- Fixed stage weights, pooled-stage competing risks and a Bayesian stage/segment/age model.
- Aggregate revenue error and bias, opportunity probability calibration, and 80%/95% predictive coverage under stable, slowdown and shared-shock conditions.

## Evaluated results

Error is sum of absolute origin-level forecast errors divided by sum of actual revenue (WAPE). Bias is forecast minus actual divided by actual. Brier score measures probability error. Forecast intervals include modeled transition uncertainty and simulated opportunity outcomes.

### stable

| Horizon | Model | Revenue error | Bias | Brier | 80% coverage | 95% coverage | Mean 95% width |
|---|---|---:|---:|---:|---:|---:|---:|
| 4 weeks | fixed_stage | 40.56% | -40.56% | 0.1673 | 8.33% | 25.00% | $244,284.39 |
| 4 weeks | pooled_stage | 15.99% | -9.35% | 0.1596 | 50.00% | 83.33% | $294,007.92 |
| 4 weeks | multistate | 15.75% | -9.22% | 0.1568 | 58.33% | 83.33% | $287,507.96 |
| 8 weeks | fixed_stage | 31.92% | -31.92% | 0.2326 | 0.00% | 8.33% | $287,638.28 |
| 8 weeks | pooled_stage | 8.52% | -3.59% | 0.2161 | 83.33% | 91.67% | $346,043.47 |
| 8 weeks | multistate | 8.69% | -5.23% | 0.2107 | 66.67% | 91.67% | $342,397.75 |
| 12 weeks | fixed_stage | 19.65% | -19.65% | 0.2573 | 16.67% | 41.67% | $305,318.51 |
| 12 weeks | pooled_stage | 6.02% | 0.66% | 0.2343 | 91.67% | 100.00% | $359,720.57 |
| 12 weeks | multistate | 6.50% | -2.98% | 0.2280 | 91.67% | 100.00% | $355,168.78 |

### slowdown

| Horizon | Model | Revenue error | Bias | Brier | 80% coverage | 95% coverage | Mean 95% width |
|---|---|---:|---:|---:|---:|---:|---:|
| 4 weeks | fixed_stage | 57.64% | 57.64% | 0.0724 | 16.67% | 41.67% | $234,217.35 |
| 4 weeks | pooled_stage | 122.04% | 122.04% | 0.0808 | 0.00% | 0.00% | $276,114.10 |
| 4 weeks | multistate | 120.42% | 120.42% | 0.0792 | 0.00% | 8.33% | $272,324.46 |
| 8 weeks | fixed_stage | 64.85% | 64.85% | 0.1325 | 0.00% | 8.33% | $287,662.84 |
| 8 weeks | pooled_stage | 123.37% | 123.37% | 0.1436 | 0.00% | 0.00% | $345,241.47 |
| 8 weeks | multistate | 116.65% | 116.65% | 0.1376 | 0.00% | 0.00% | $333,920.87 |
| 12 weeks | fixed_stage | 88.20% | 88.20% | 0.1776 | 0.00% | 0.00% | $304,884.36 |
| 12 weeks | pooled_stage | 129.12% | 129.12% | 0.1779 | 0.00% | 0.00% | $366,729.31 |
| 12 weeks | multistate | 116.57% | 116.57% | 0.1666 | 0.00% | 0.00% | $358,088.48 |

### shared_shocks

| Horizon | Model | Revenue error | Bias | Brier | 80% coverage | 95% coverage | Mean 95% width |
|---|---|---:|---:|---:|---:|---:|---:|
| 4 weeks | fixed_stage | 48.30% | -48.30% | 0.1924 | 8.33% | 25.00% | $235,979.59 |
| 4 weeks | pooled_stage | 27.81% | 4.22% | 0.1755 | 33.33% | 58.33% | $310,091.69 |
| 4 weeks | multistate | 27.05% | 3.01% | 0.1730 | 33.33% | 58.33% | $303,473.55 |
| 8 weeks | fixed_stage | 40.52% | -40.52% | 0.2605 | 8.33% | 16.67% | $282,959.27 |
| 8 weeks | pooled_stage | 20.04% | 6.47% | 0.2313 | 41.67% | 58.33% | $351,297.57 |
| 8 weeks | multistate | 18.18% | 2.97% | 0.2253 | 50.00% | 50.00% | $352,007.60 |
| 12 weeks | fixed_stage | 28.81% | -28.81% | 0.2758 | 8.33% | 16.67% | $301,942.88 |
| 12 weeks | pooled_stage | 15.95% | 9.03% | 0.2450 | 33.33% | 75.00% | $363,485.37 |
| 12 weeks | multistate | 12.98% | 3.43% | 0.2377 | 66.67% | 75.00% | $355,214.17 |

The detailed model does not dominate the pooled baseline in the stable process. In the slowdown case, optimistic historical transition rates persist in the expanding window; the ranges miss a structural process change. Shared shocks also reduce interval coverage. These adverse results are decision-relevant and remain part of the study.

## Assumptions and limitations

- Only transitions strictly before a forecast cutoff enter estimation; the open snapshot contains start-of-week features only.
- Observed past transitions of currently open deals are valid information. Their later outcomes are excluded until their event dates.
- Deal values stay fixed and are recognized fully upon winning; future-created deals, partial recognition and pipeline revisions are excluded.
- The conditional transition process must remain useful. Posterior parameter sharing does not represent an unobserved market-wide shock.

This is a completed synthetic evaluation, not demonstrated CRM accuracy. Twelve overlapping forecast windows provide limited, dependent evidence about interval coverage. Process drift and correlated deals can invalidate the predictive ranges, as the stress tests show. The more detailed model is not uniformly better than the simpler baseline.

## Reproduction and checks

Run the README commands. Nine tests pass, including hand-calculated or exhaustive fixtures, temporal leakage attempts and seeded determinism. The protocol, configuration, lockfile, model code, detailed evaluation CSVs and content hashes are included. No favorable seeds were selected after seeing results. Numerical libraries are pinned; stored results round to six decimal places to make reproduction portable.

## Next practical step

Run the frozen approach in shadow mode on authorized CRM snapshots. Define booked revenue, versioned opportunity fields, horizon-specific alert thresholds and a process-change response before assessing actual forecast quality.

## Method references

- [Putter, Fiocco & Geskus — competing risks and multi-state models](https://doi.org/10.1002/sim.2712)

These references motivate the design; this implementation does not claim their complete estimators or theoretical guarantees.
