# Sales pipeline forecasting protocol

Decision: estimate booked revenue from the opportunities already open at a forecast cutoff, over 4, 8 and 12 weeks. Future opportunity creation is excluded. Currency is USD; a win books the full opportunity amount once, a loss books zero.

Original synthetic CRM histories have three nonterminal stages (qualified, proposal, negotiation), win/loss absorbing events, segment and deal amount fixed on entry, and weekly snapshots. Exposure at the beginning of a week and transitions at its end are distinct. A forecast at week t uses only transitions strictly before t and open snapshots at t. Open deals contribute risk exposure but are not relabeled as losses. Earlier observed transitions for a currently open deal are permitted information; future transitions are not.

Primary method: Bayesian discrete-time competing-risk, multistate model. Estimate stage × segment × age-band transition distributions with symmetric Dirichlet(0.5) smoothing. Possible transitions are stay, advance, win and loss (advance is disabled at final stage). Age bands are under 4, 4–7 and at least 8 weeks. Propagate transition probabilities to cumulative win probabilities. Posterior predictive draws share a sampled transition table across deals and then simulate each deal path, carrying age and stage forward. This incorporates transition-estimation uncertainty and deal randomness, but no unobserved market-wide shock.

Baselines: fixed stage weights [0.15, 0.40, 0.70], converted to each horizon as 1−(1−weight)^(h/12); and a pooled-stage competing-risk model without segment/age conditioning. All approaches forecast the identical open pipeline. Fixed weights are a declared comparator, not claimed real CRM defaults.

Evaluation: twelve forecast origins at weeks 120 through 164, four weeks apart, with all outcomes observed by week 176. Fit expanding historical exposures separately at every cutoff; no final-period tuning. Report aggregate absolute percentage error (sum absolute errors / sum actual booked revenue), signed bias, opportunity-level Brier score and probability calibration, 80%/95% predictive coverage and mean interval width, and origin-level forecast CSVs. Posterior simulation uses 500 fixed-seed draws per origin. Predictive intervals are marginal, not simultaneous guarantees. Overlapping horizons and repeated deals make origins dependent; coverage across twelve origins is descriptive, not a precise population estimate.

Robustness: stable transitions; a persistent conversion slowdown beginning at the first held-out origin; and correlated weekly market shocks. Use identical seed schedules with no favorable-seed selection. Publish every scenario and baseline, including deterioration. No claim about real CRM accuracy, generalization or operational readiness follows from simulation.

Correctness: hand-calculated absorbing transitions; cumulative probability monotonicity; probability conservation; deterministic seeds; future-outcome mutation leaves fitted tables and forecasts unchanged; open-deal censoring; interval ordering. Independent technical review remains pending.

Reference: Putter, Fiocco & Geskus (2007), Tutorial in biostatistics: competing risks and multi-state models. https://doi.org/10.1002/sim.2712 . This study uses a discrete-time transition model, not that article's exact continuous-time estimator.
