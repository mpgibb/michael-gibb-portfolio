# Sales pipeline and revenue forecasting

Completed reproducible synthetic study · Python 3.11.16 · NumPy 2.2.6 · SciPy 1.17.1

Case study: https://michaelpgibb.com/projects/revenue-forecasting

## Executive summary

**A better forecast still needs a warning system.**

In the stable simulation, the detailed model's 12-week revenue error was 6.5%, versus 19.6% for fixed stage weights. The simpler timing model was slightly more accurate at 6.0%.

Decision implication: Pilot the forecast alongside the existing sales process, with clear alerts when conversion rates or deal timing change.

Key caution: When the simulated sales process slowed abruptly, all twelve 95% forecast ranges missed. The forecast covers only opportunities already open. It cannot support a firm revenue commitment.

All findings describe synthetic data. They are not client results. Independent technical review remains pending.

## Reproduce

```bash
git clone https://github.com/mpgibb/revenue-forecasting.git
cd revenue-forecasting
uv sync --frozen
uv run python -W error -m unittest discover -s tests -v
uv run python -W error study.py
git diff --exit-code -- data results
```

The frozen `uv.lock` resolves the pinned numerical libraries. The pipeline requires no credentials, paid data or network calls after environment setup. Nine correctness tests cover numerical fixtures, information timing and decision constraints. Running the study regenerates every CSV and `results/summary.json` from `config.json`. Monetary and probability outputs are rounded to six decimal places when serialized; forecast comparisons use the unrounded calculations.

## Research materials

- [PROTOCOL.md](PROTOCOL.md): question, models, baselines, timing and evaluation design recorded before evaluation.
- [DATA.md](DATA.md): units, schema, observation windows and permitted model inputs.
- [REPORT.md](REPORT.md): complete comparisons, robustness, practical implications and limits.
- `study.py` and `common.py`: generator, model, evaluator and numerical/provenance utilities.
- `tests/`: hand-calculated and adversarial correctness checks.
- `data/`: original generated observations; evaluator-only oracle files where applicable.
- `results/`: detailed predictions/decisions and machine-readable summaries, including source/data SHA-256 hashes.

## Scope and use

This is a completed synthetic evaluation, not demonstrated CRM accuracy. Twelve overlapping forecast windows provide limited, dependent evidence about interval coverage. Process drift and correlated deals can invalidate the predictive ranges, as the stress tests show. The more detailed model is not uniformly better than the simpler baseline.

Run the frozen approach in shadow mode on authorized CRM snapshots. Define booked revenue, versioned opportunity fields, horizon-specific alert thresholds and a process-change response before assessing actual forecast quality.

The synthetic data are original study materials and contain no customer or employer records. No original source/data reuse license has been selected; public availability permits inspection but does not itself grant reuse rights. Numerical libraries retain their own licenses and are installed from the lockfile, not vendored here.
