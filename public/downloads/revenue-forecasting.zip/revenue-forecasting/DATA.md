# Data dictionary and observation rules

The generator creates 5,760 opportunities per scenario (180 weeks × 32 arrivals). `data/*_events.csv` has one row per opportunity at risk at the beginning of each week, including the observed transition at that week’s end.

| Field | Meaning / unit | Forecast availability |
|---|---|---|
| deal_id | Synthetic opportunity identifier | Known at entry |
| week | Zero-based exposure week | Current or earlier |
| entry_week | Creation week | Known at entry |
| segment | Synthetic segment 0 or 1 | Fixed at entry |
| amount | USD booked on win, fixed | Known at entry |
| stage | 0 qualified; 1 proposal; 2 negotiation | Start of week |
| age_weeks | week minus entry_week | Start of week |
| transition | 0 stay; 1 advance one stage; 2 win; 3 loss | End of week only |

Forecast t uses `week < t` transitions and the five known fields in the open snapshot at t. Win/loss events are absorbing; subsequent exposure rows do not exist. Deals still open when observation stops remain censored. There are no deleted or backdated records, revisions, missing fields, partial bookings or future-created deals in the forecast target.

`results/*_forecasts.csv` records each origin, horizon, method, actual booked revenue, forecast, interval endpoints, open-deal count and Brier score. Calibration tables aggregate opportunity snapshots (a deal can recur at later origins). Full source/data hashes appear in `results/summary.json`.

Generation probabilities and scenario shifts are fully specified in `generate()` and `config.json`. The fixed stage weights are declared comparators, not estimates from a real company. Files use six decimal places for numeric fields; identifiers and enumerations represented numerically retain their integer meaning.
