import unittest
import numpy as np
from study import age_band,generate,fit_tables,snapshot,win_probability,predictive_draws,observed_wins,CONFIG

class ForecastTests(unittest.TestCase):
    def setUp(self):
        self.config={**CONFIG,'weeks':24,'arrivals_per_week':4}
        self.events=generate(self.config,'stable')
    def test_reproducible_generation(self):
        np.testing.assert_array_equal(self.events,generate(self.config,'stable'))
    def test_age_boundaries(self):
        np.testing.assert_array_equal(age_band([0,3,4,7,8,40]),[0,0,1,1,2,2])
    def test_competing_risk_by_hand(self):
        table=np.zeros((3,1,1,4));table[:,:,:,0]=.5;table[:,:,:,2]=.2;table[:,:,:,3]=.3
        current=np.array([[1,0,100,0,0]])
        self.assertAlmostEqual(win_probability(table,current,2)[0],.2+.5*.2)
    def test_stage_progression_by_hand(self):
        table=np.zeros((3,1,1,4));table[0,0,0,1]=1;table[1,0,0,2]=1;table[2,0,0,3]=1
        current=np.array([[1,0,100,0,0]])
        self.assertEqual(win_probability(table,current,1)[0],0)
        self.assertEqual(win_probability(table,current,2)[0],1)
    def test_future_outcomes_cannot_change_fit(self):
        other=self.events.copy();other[other[:,1]>=12,7]=3
        np.testing.assert_array_equal(fit_tables(self.events,12),fit_tables(other,12))
        np.testing.assert_array_equal(snapshot(self.events,12),snapshot(other,12))
    def test_open_deals_contribute_exposure_not_losses(self):
        fixture=np.array([[0,0,0,0,100,0,0,0],[0,1,0,0,100,0,1,0]],float)
        table=fit_tables(fixture,2)
        self.assertEqual(table[0,0,0,0],2.5)
        self.assertEqual(table[0,0,0,3],.5)
    def test_probability_conservation_and_monotonicity(self):
        alpha=fit_tables(self.events,12);table=alpha/alpha.sum(axis=-1,keepdims=True)
        np.testing.assert_allclose(table.sum(axis=-1),1)
        self.assertTrue(np.all(table[2,:,:,1]==0))
        c=snapshot(self.events,12);p1=win_probability(table,c,4);p2=win_probability(table,c,12)
        self.assertTrue(np.all((p1>=0)&(p2<=1)&(p1<=p2)))
    def test_predictive_interval_order_and_reproducibility(self):
        args=(fit_tables(self.events,12),snapshot(self.events,12),[4,8],100,12)
        a=predictive_draws(*args);b=predictive_draws(*args)
        for h in a:
            np.testing.assert_array_equal(a[h],b[h]);self.assertTrue(np.all(np.diff(a[h])>=0))
    def test_win_window_excludes_preexisting_and_future_closures(self):
        events=np.array([[1,3,0,0,100,2,3,2],[2,4,0,0,200,2,4,2],[3,8,0,0,300,2,8,2]],float)
        current=np.array([[1,0,100,2,4],[2,0,200,2,4],[3,0,300,2,4]])
        np.testing.assert_array_equal(observed_wins(events,current,4,4),[0,1,0])

if __name__=='__main__':unittest.main()
