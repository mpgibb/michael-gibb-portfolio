"""Point-in-time competing-risk pipeline forecast and synthetic evaluation."""
from pathlib import Path
import json
import numpy as np
from common import write_csv,save_summary,calibration

CONFIG=json.loads(Path('config.json').read_text())
METHODS=['fixed_stage','pooled_stage','multistate']

def age_band(age):return np.minimum(np.asarray(age)//4,2).astype(int)

def generate(config,scenario):
    rng=np.random.default_rng(config['seed']);active=[];rows=[];deal_id=0
    shocks=rng.normal(0,.65,config['weeks'])
    for week in range(config['weeks']):
        for _ in range(config['arrivals_per_week']):
            active.append([deal_id,week,int(rng.integers(0,2)),round(float(rng.lognormal(9,.65)),2),0]);deal_id+=1
        surviving=[]
        for deal,entry,segment,amount,stage in active:
            age=week-entry
            win=[.012,.065,.17][stage]*(1+.3*segment)*np.exp(-.045*max(age-4,0))
            advance=[.20,.17,0][stage]*(1+.15*segment)
            loss=[.045,.065,.09][stage]+.004*age
            if scenario=='slowdown' and week>=120:win*=.45;advance*=.65;loss*=1.3
            if scenario=='shared_shocks':win*=np.exp(shocks[week]);loss*=np.exp(-.35*shocks[week])
            probs=np.array([advance,win,loss]);probs*=min(1,.92/probs.sum())
            transition=int(rng.choice(4,p=[1-probs.sum(),*probs]))
            rows.append((deal,week,entry,segment,amount,stage,age,transition))
            if transition<2:surviving.append([deal,entry,segment,amount,stage+int(transition==1)])
        active=surviving
    return np.asarray(rows,dtype=float)

def fit_tables(events,cutoff,pooled=False):
    history=events[events[:,1]<cutoff]
    shape=(3,1,1,4) if pooled else (3,2,3,4)
    alpha=np.full(shape,CONFIG['prior']);alpha[2,:,:,1]=0
    for row in history:
        s=int(row[5]);g=0 if pooled else int(row[3]);a=0 if pooled else int(age_band(row[6]))
        alpha[s,g,a,int(row[7])]+=1
    return alpha

def snapshot(events,cutoff):
    # Only known start-of-week features enter the forecasting interface.
    return events[events[:,1]==cutoff][:,[0,3,4,5,6]].copy()

def win_probability(table,current,horizon):
    stage=current[:,3].astype(int);age=current[:,4].astype(int)
    segment=current[:,1].astype(int) if table.shape[1]>1 else np.zeros(len(current),int)
    mass=np.eye(3)[stage];won=np.zeros(len(current))
    for step in range(horizon):
        band=age_band(age+step) if table.shape[2]>1 else np.zeros(len(current),int)
        nxt=np.zeros_like(mass)
        for s in range(3):
            p=table[s,segment,band]
            won+=mass[:,s]*p[:,2]
            nxt[:,s]+=mass[:,s]*p[:,0]
            if s<2:nxt[:,s+1]+=mass[:,s]*p[:,1]
        mass=nxt
    return won

def predictive_draws(alpha,current,horizons,draws,seed):
    rng=np.random.default_rng(seed)
    gamma=rng.gamma(np.where(alpha>0,alpha,1),size=(draws,*alpha.shape))
    gamma*=alpha>0;tables=gamma/gamma.sum(axis=-1,keepdims=True)
    n=len(current);stage=np.tile(current[:,3].astype(int),(draws,1));alive=np.ones((draws,n),bool)
    segment=current[:,1].astype(int) if alpha.shape[1]>1 else np.zeros(n,int)
    amount=current[:,2];age=current[:,4].astype(int);revenue=np.zeros(draws);out={}
    for step in range(1,max(horizons)+1):
        band=age_band(age+step-1) if alpha.shape[2]>1 else np.zeros(n,int)
        p=tables[np.arange(draws)[:,None],stage,segment[None,:],band[None,:]]
        event=(rng.random((draws,n,1))>p.cumsum(axis=-1)).sum(axis=-1)
        revenue+=np.sum((alive&(event==2))*amount,axis=1)
        stage=np.minimum(stage+(alive&(event==1)),2)
        alive &= event<2
        if step in horizons:out[step]=np.quantile(revenue,[.025,.1,.9,.975])
    return out

def observed_wins(events,current,origin,horizon):
    won=events[(events[:,1]>=origin)&(events[:,1]<origin+horizon)&(events[:,7]==2),0]
    return np.isin(current[:,0],won).astype(float)

def evaluate(config,scenario):
    events=generate(config,scenario)
    write_csv(f'data/{scenario}_events.csv',['deal_id','week','entry_week','segment','amount','stage','age_weeks','transition'],events)
    records=[];probabilities={};exposures=[]
    for origin in config['origins']:
        current=snapshot(events,origin)
        exposures.append({'origin':origin,'open_deals':len(current),'training_exposures':int((events[:,1]<origin).sum()),'max_training_week':origin-1})
        for method in METHODS:
            if method=='fixed_stage':
                table=None;intervals={}
            else:
                alpha=fit_tables(events,origin,method=='pooled_stage');table=alpha/alpha.sum(axis=-1,keepdims=True)
                intervals=predictive_draws(alpha,current,config['horizons'],config['draws'],config['seed']+origin+(method=='pooled_stage')*1000)
            for horizon in config['horizons']:
                y=observed_wins(events,current,origin,horizon);actual=np.sum(y*current[:,2])
                if table is None:
                    weights=np.array([.15,.4,.7])[current[:,3].astype(int)]
                    p=1-(1-weights)**(horizon/12)
                    rng=np.random.default_rng(config['seed']+origin+horizon)
                    samples=np.sum((rng.random((config['draws'],len(current)))<p)*current[:,2],axis=1)
                    interval=np.quantile(samples,[.025,.1,.9,.975])
                else:p=win_probability(table,current,horizon);interval=intervals[horizon]
                pred=np.sum(p*current[:,2])
                records.append([origin,horizon,method,actual,pred,*interval,len(current),float(np.mean((p-y)**2))])
                probabilities.setdefault((horizon,method),[]).append((p,y))
    write_csv(f'results/{scenario}_forecasts.csv',['origin_week','horizon_weeks','method','actual','forecast','lower95','lower80','upper80','upper95','open_deals','brier'],records)
    metrics={}
    for horizon in config['horizons']:
        metrics[horizon]={}
        for method in METHODS:
            r=[r for r in records if r[1]==horizon and r[2]==method]
            actual=np.array([v[3] for v in r]);pred=np.array([v[4] for v in r]);intervals=np.array([v[5:9] for v in r])
            p=np.concatenate([v[0] for v in probabilities[horizon,method]]);y=np.concatenate([v[1] for v in probabilities[horizon,method]])
            metrics[horizon][method]={'wape':np.abs(actual-pred).sum()/actual.sum(),'bias_fraction':(pred-actual).sum()/actual.sum(),'brier':np.mean((p-y)**2),'coverage80':np.mean((actual>=intervals[:,1])&(actual<=intervals[:,2])),'coverage95':np.mean((actual>=intervals[:,0])&(actual<=intervals[:,3])),'mean_width95':np.mean(intervals[:,3]-intervals[:,0]),'calibration':calibration(y,p),'mean_actual':actual.mean()}
    return {'scenario':scenario,'events':len(events),'deals':int(events[:,0].max()+1),'origins':exposures,'metrics':metrics}

def main():
    summary={'study':'revenue-forecasting','config':CONFIG,'methods':METHODS,'scenarios':[evaluate(CONFIG,s) for s in CONFIG['scenarios']]}
    save_summary(summary)
    print(json.dumps({s['scenario']:s['metrics'][12] for s in summary['scenarios']},default=float,indent=2))

if __name__=='__main__':main()
